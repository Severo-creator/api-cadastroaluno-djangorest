senha postgresql = 'senha_forte_aqui'
User postgresql = 'cadastro_user'
senha admin Django = 2444
user admin Django = 'gui'
